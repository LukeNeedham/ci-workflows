@file:OptIn(InternalResourceApi::class)

package com.lukeneedham.common.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem

private const val MD: String = "composeResources/com.lukeneedham.common.resources/"

@delegate:ResourceContentHash(-671_399_898)
internal val Res.drawable.ic_back: DrawableResource by lazy {
      DrawableResource("drawable:ic_back", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_back.xml", -1, -1),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainDrawable0Resources(map: MutableMap<String, DrawableResource>) {
  map.put("ic_back", Res.drawable.ic_back)
}
